#include "playlist.h"
#include <QFileDialog>
#include <QUrl>
#include <QDebug>

Playlist::Playlist()
    : currentIndex(0), player(new QMediaPlayer) {
    qDebug() << "QMediaPlayer creado.";
}

Playlist::~Playlist() {
    delete player;
}

void Playlist::addMedia(const QString &mediaPath) {
    mediaList.append(mediaPath);
    qDebug() << "Añadido media:" << mediaPath;
}

void Playlist::play(int index) {
    if (index >= 0 && index < mediaList.size()) {
        currentIndex = index;
        player->setSource(QUrl::fromLocalFile(mediaList.at(index)));
        qDebug() << "Configurado media:" << mediaList.at(index);
        player->play();
        qDebug() << "Reproduciendo media:" << mediaList.at(index);
    }
}

void Playlist::next() {
    if (currentIndex + 1 < mediaList.size()) {
        play(currentIndex + 1);
    }
}

void Playlist::previous() {
    if (currentIndex - 1 >= 0) {
        play(currentIndex - 1);
    }
}

void Playlist::loadSongs() {
    QStringList files = QFileDialog::getOpenFileNames(nullptr, "Selecciona canciones", "", "Audio Files (*.mp3 *.wav)");
    for (const QString &filePath : files) {
        addMedia(filePath);
    }
}
