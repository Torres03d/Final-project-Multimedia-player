#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QList>
#include <QMediaPlayer>
#include <QString>

class Playlist {
public:
    Playlist();
    ~Playlist();

    void addMedia(const QString &mediaPath);
    void play(int index);
    void next();
    void previous();
    void loadSongs();

private:
    QList<QString> mediaList;
    int currentIndex;
    QMediaPlayer *player;
};

#endif // PLAYLIST_H
