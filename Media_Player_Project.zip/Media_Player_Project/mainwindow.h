#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtMultimedia>
#include <QtMultimediaWidgets>
#include <QtCore>
#include <QtWidgets>
#include <QtGui>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void durationChanged(quint64 duration);
    void positionChanged(quint64 duration);
    void on_pushButton_Play_clicked();
    void on_pushButton_Stop_clicked();
    void on_pushButton_Volume_clicked();
    void on_horizontalSlider_Volume_valueChanged(int value);
    void on_horizontalSlider_Duration_valueChanged(int value);
    void on_actionOpen_triggered();
    void on_pushButton_Seek_Backward_clicked();
    void on_pushButton_Seek_Forward_clicked();

private:
    Ui::MainWindow *ui;
    QMediaPlayer *Player;
    QVideoWidget *Video;
    QAudioOutput *audioOutput;
    quint64 mDuration;
    bool IS_Pause = true;
    bool IS_Muted = false;
    void updateDuration(quint64 Duration);
    void updateCurrentTime(qint64 current);
    void updateTotalTime(qint64 total);

    QLabel *mediaTitleLabel;
    QVideoWidget *videoWidget;
    QLabel *albumArtLabel;
    void displayMedia(const QString& fileName, bool isVideo);
};

#endif // MAINWINDOW_H
